#ifndef DSASL_CLIENT_MECH_NTLM_DUMMY_H
#define DSASL_CLIENT_MECH_NTLM_DUMMY_H

void dsasl_client_mech_ntlm_init_dummy(void);

#endif
