#ifndef DOC_H
#define DOC_H

#ifdef HAVE_CONFIG_H
#  include "config.h"
#endif

#define DOC_LINK(page) DOVECOT_DOC_URL "latest/" page

#endif
