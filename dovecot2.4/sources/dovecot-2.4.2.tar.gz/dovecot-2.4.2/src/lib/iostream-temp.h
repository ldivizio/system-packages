#ifndef IOSTREAM_TEMP_H
#define IOSTREAM_TEMP_H

enum iostream_temp_flags {
	/* if o_stream_send_istream() is called with a readable fd, don't
	   actually copy the input stream, just have iostream_temp_finish()
	   return a new iostream pointing to the fd dup()ed */
	IOSTREAM_TEMP_FLAG_TRY_FD_DUP	= 0x01
};

/* Start writing to given output stream. The data is initially written to
   memory, and later to a temporary file that is immediately unlinked. */
struct ostream *iostream_temp_create(const char *temp_path_prefix,
				     enum iostream_temp_flags flags);
struct ostream *iostream_temp_create_named(const char *temp_path_prefix,
					   enum iostream_temp_flags flags,
					   const char *name);
struct ostream *iostream_temp_create_sized(const char *temp_path_prefix,
					   enum iostream_temp_flags flags,
					   const char *name,
					   size_t max_mem_size);
/* Finished writing to stream. Return input stream for it and free the
   output stream. (It's also possible to abort iostream-temp by simply
   destroying the ostream.) */
struct istream *iostream_temp_finish(struct ostream **output,
				     size_t max_buffer_size);

/* For internal testing: */
void o_stream_temp_set_writev(struct ostream *output,
			      ssize_t (*func)(int fd, const struct iovec *iov,
					      unsigned int iov_count));

#endif
