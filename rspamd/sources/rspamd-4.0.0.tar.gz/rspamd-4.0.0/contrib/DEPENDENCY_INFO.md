# Rspamd Dependency Info

| Name                   | Version | License             | Patched | Notes               |
|------------------------|---------|---------------------|---------|---------------------|
| aho-corasick           | ?       | LGPL-3.0            | YES     | lowercase support   |
| cdb                    | 1.1.0   | Public Domain / CC0 | NO      |                     |
| hiredis                | 1.2.0   | BSD-3-Clause        | NO      |                     |
| libev                  | 4.33    | BSD-2-Clause        | YES     | many changes        |
| lc-btrie               | ?       | BSD-3-Clause        | YES     | mempool support     |
| libottery              | ?       | Public Domain / CC0 | YES     | many changes        |
| librdns                | ?       | BSD-2-Clause        | YES     |                     |
| libucl                 | ?       | BSD-2-Clause        | YES     |                     |
| replxx                 | 6d93360 | BSD-2-Clause        | YES     | libicu, libc++ link |
| lua-argparse           | 0.7.1   | MIT                 | NO      |                     |
| lua-bit                | 1.0.2   | MIT                 | YES     | build fixes         |
| lua-fun                | ?       | MIT                 | YES     | rspamd text         |
| lua-lpeg               | 1.0     | MIT                 | YES     | rspamd text + alloc |
| lua-moses              | ?       | MIT                 | NO      |                     |
| lua-lupa               | ?       | MIT                 | NO      |                     |
| lua-tableshape         | 2.6.0   | MIT                 | NO      |                     |
| mumhash                | ?       | MIT                 | NO      |                     |
| ngx-http-parser        | 2.2.0   | MIT                 | YES     | spamc support       |
| Mozilla-PublicSuffix   | ?       | MIT                 | NO      |                     |
| snowball               | ?       | BSD-3-Clause        | NO      |                     |
| t1ha                   | ?       | Zlib                | NO      |                     |
| uthash                 | 1.9.8   | BSD                 | YES     |                     |
| xxhash                 | 0.8.1   | BSD                 | NO      |                     |
| zstd                   | 1.5.4   | BSD                 | YES     | build fixes only    |
| google-ced             | 37529e6 | Apache 2            | YES     | build fixes         |
| kann                   | ?       | MIT                 | YES     | blas/lapack changes |
| fpconv                 | ?       | Boost               | YES     | many changes        |
| simdutf                | ef7d39c | Apache 2            | NO      | build system only   |
| expected               | v1.0    | Public Domain / CC0 | NO      |                     |
| frozen                 | 1.0.1   | Apache 2            | NO      |                     |
| fmt                    | 12.1.0  | MIT                 | NO      |                     |
| doctest                | 2.4.11  | MIT                 | NO      |                     |
| function2              | 4.1.0   | Boost               | NO      |                     |
| ankerl/svector         | 1.0.2   | MIT                 | NO      |                     |
| ankerl/unordered_dense | 4.4.0   | MIT                 | NO      |                     |
| backward-cpp           | 1.6     | MIT                 | NO      |                     |

