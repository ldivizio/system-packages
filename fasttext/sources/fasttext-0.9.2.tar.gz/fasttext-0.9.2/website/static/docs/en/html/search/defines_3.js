var searchData=
[
  ['sigmoid_5ftable_5fsize',['SIGMOID_TABLE_SIZE',['../model_8h.html#a2e8aaf1ce5284c2017df4d6a3b631532',1,'model.h']]]
];
